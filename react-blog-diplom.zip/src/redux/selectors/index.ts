export const postData = (state: { posts: { postData: object[]; } }) => state.posts.postData
export const allPost = (state: { allPost: any }) => state.allPost