export const CREATE_POST = 'CREATE_POST'
export const GET_POST = 'GET_POST'
export const SET_POSTS = 'SET_POSTS'
export const GET_ALL_POST = 'GET_ALL_POST'